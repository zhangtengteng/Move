/*
 * 
 */
package com.ab.view.level;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class AbLevelSeries.
 */
public class AbLevelSeries implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new ab level series.
	 */
	public AbLevelSeries() {
		super();
	}

}

/*
 * 
 */
package com.ab.model;


// TODO: Auto-generated Javadoc
/**
 * �����������ļ�.
 *
 * @author zhaoqp
 * @date��2012-6-25 ����4:20:55
 * @version v1.0
 */
public class DownFile {
	
	/** Ψһ��ʶ. */
	private int _ID;
	
	/** ͼ��. */
	private String icon;
	
	/** �ļ�����. */
	private String name;
	
	/** �ļ����. */
	private String description;
	
	/** �����apk�ļ���ʾ����. */
	private String pakageName;
	
	/** 1��ʾ��������� 0��ʾδ��ʼ���� 2��ʾ�ѿ�ʼ����. */
	private int state;
	
	/** �ļ�����·��. */
	private String downUrl;
	
	/** �ļ�����·��. */
	private String downPath;
	
	/** �ļ���ǰ���ش�С. */
	private int downLength;
	
	/** �ļ��ܴ�С. */
	private int totalLength;

	/**
	 * Gets the  id.
	 *
	 * @return the  id
	 */
	public int get_ID() {
		return _ID;
	}

	/**
	 * Sets the  id.
	 *
	 * @param _ID the new  id
	 */
	public void set_ID(int _ID) {
		this._ID = _ID;
	}

	/**
	 * Gets the icon.
	 *
	 * @return the icon
	 */
	public String getIcon() {
		return icon;
	}

	/**
	 * Sets the icon.
	 *
	 * @param icon the new icon
	 */
	public void setIcon(String icon) {
		this.icon = icon;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the pakage name.
	 *
	 * @return the pakage name
	 */
	public String getPakageName() {
		return pakageName;
	}

	/**
	 * Sets the pakage name.
	 *
	 * @param pakageName the new pakage name
	 */
	public void setPakageName(String pakageName) {
		this.pakageName = pakageName;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public int getState() {
		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(int state) {
		this.state = state;
	}

	/**
	 * Gets the down url.
	 *
	 * @return the down url
	 */
	public String getDownUrl() {
		return downUrl;
	}

	/**
	 * Sets the down url.
	 *
	 * @param downUrl the new down url
	 */
	public void setDownUrl(String downUrl) {
		this.downUrl = downUrl;
	}

	/**
	 * Gets the down path.
	 *
	 * @return the down path
	 */
	public String getDownPath() {
		return downPath;
	}

	/**
	 * Sets the down path.
	 *
	 * @param downPath the new down path
	 */
	public void setDownPath(String downPath) {
		this.downPath = downPath;
	}

	/**
	 * Gets the down length.
	 *
	 * @return the down length
	 */
	public int getDownLength() {
		return downLength;
	}

	/**
	 * Sets the down length.
	 *
	 * @param downLength the new down length
	 */
	public void setDownLength(int downLength) {
		this.downLength = downLength;
	}

	/**
	 * Gets the total length.
	 *
	 * @return the total length
	 */
	public int getTotalLength() {
		return totalLength;
	}

	/**
	 * Sets the total length.
	 *
	 * @param totalLength the new total length
	 */
	public void setTotalLength(int totalLength) {
		this.totalLength = totalLength;
	}
	
	
}

package com.ab.global;


// TODO: Auto-generated Javadoc
/**
 * The Class AbAppData.
 */
public class AbAppData {
	
	/** ��־����. */
	public static  boolean DEBUG = false;

}

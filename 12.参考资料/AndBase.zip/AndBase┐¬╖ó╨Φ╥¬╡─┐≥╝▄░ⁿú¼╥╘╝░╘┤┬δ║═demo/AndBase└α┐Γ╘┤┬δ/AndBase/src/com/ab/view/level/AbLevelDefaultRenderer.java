/*
 * 
 */
package com.ab.view.level;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class AbLevelDefaultRenderer.
 */
public class AbLevelDefaultRenderer implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new ab level default renderer.
	 */
	public AbLevelDefaultRenderer() {
		super();
	}

}

var searchData=
[
  ['_5bstatic_20initializer_5d',['[static initializer]',['../classcom_1_1ab_1_1bitmap_1_1_ab_file_cache.html#af2af5b5892acf2ac68a25737b5a2b0d0',1,'com::ab::bitmap::AbFileCache']]]
];
